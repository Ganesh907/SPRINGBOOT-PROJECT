package com.njoytoyshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NJoyToyShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(NJoyToyShopApplication.class, args);
	}

}
